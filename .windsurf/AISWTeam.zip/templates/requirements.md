# Requirements

## Problem statement
## Goals
## Non-goals
## Constraints
## Domain model (entities & invariants)
## User flows / operations
## Edge cases
## Open decisions (link D-...)
## Clarification Q/A (question_id + answer)

## Requirements ACK packet (summary for client)
- What you are approving
- List AC-xx titles
- Key assumptions
