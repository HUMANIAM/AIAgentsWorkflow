# Open Questions

- Q-01:
  - Priority: blocking | non_blocking | nice_to_have
  - Question:
  - Default if unanswered:
