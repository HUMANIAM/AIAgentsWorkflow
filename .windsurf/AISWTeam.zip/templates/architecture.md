# Architecture

## Overview
## Components & boundaries
## Data model + invariants
## API contracts
## UI states (if relevant)
## AC mapping (AC-xx -> responsibilities + verification)
## Technology choices (link D-... decisions)
## ChangeSet slice plan
