# Assumptions (explicit)

- A-01:
  - Assumption:
  - Why needed:
  - Risk:
  - How to confirm:
  - Related AC / D-...:
