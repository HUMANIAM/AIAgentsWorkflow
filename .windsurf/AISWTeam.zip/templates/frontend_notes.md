# Frontend Notes

## ChangeSet
## Intent
## Related AC scenarios
## Related decisions (D-...)
## Evidence (tests run, outputs, CI status)
## Files touched
## Reviewer notes (append)
