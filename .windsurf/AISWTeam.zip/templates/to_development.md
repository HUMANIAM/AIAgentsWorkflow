# To Development

## Slice plan summary
## Must-pass AC list
## Decisions to follow (D-...)
## CI and entrypoints requirements
- CI must run on PRs to main
- CI must call the same entrypoints used locally (e.g., make check)
