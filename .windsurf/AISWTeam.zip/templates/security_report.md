# Security Report

## Scope + assumptions
## Findings
- F-01:
  - Severity:
  - Evidence:
  - Fix:

## Verdict
approved | changes_requested

## Reviewer notes (append)
